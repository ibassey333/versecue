// ============================================
// Display Components Index
// ============================================

export { ScriptureDisplay, DisplayPage } from './ScriptureDisplay';
